#!/bin/zsh
set -e
SRC="$HOME/Downloads/Lab-8"
HERE="$(cd "$(dirname "$0")" && pwd)"

cp "$SRC/Software/EE446_TinyML_Lab8.ipynb" "$HERE/EE446_TinyML_Lab8.ipynb"
cp "$SRC/Software/build/model.h" "$HERE/model.h"

echo "Final files copied successfully:"
ls -lh "$HERE/EE446_TinyML_Lab8.ipynb" "$HERE/model.h"
