EE 446 TinyML Lab 8 - Submission Package

Required by the lab instructions:
1. Completed .ipynb notebook
2. Submission PDF
3. Arduino .ino file
4. model.h
5. Any other files needed to rerun or verify the work

Included here:
- EE446_TinyML_Lab8.ipynb
  Corrected source: categorical_crossentropy + accuracy, and accuracy plotting.
  IMPORTANT: the original uploaded ZIP was from before your final local run, so the
  old instructor-run training outputs were cleared rather than left inconsistent.
  If you want the exact executed notebook you just ran on your Mac, replace this file
  with your local EE446_TinyML_Lab8.ipynb before submission.
- Lab8_Report.pdf
- Lab8_Report.tex (Overleaf source)
- lab9-classifier-dual-board.ino
- hi.csv
- sup.csv
- report_assets/serial_hi.png
- report_assets/serial_sup.png

MODEL.H:
Your successful model.h was generated locally on your Mac after the ZIP was uploaded,
so its bytes are not available in this chat. Copy your tested file into this folder:
  ~/Downloads/Lab-8/Software/build/model.h

Do not submit this package as final until model.h is present.
